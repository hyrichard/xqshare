"""
XtQuant Share (xqshare) - Transparent remote proxy for xtquant library

Allows using xtquant on macOS/Linux by proxying calls to a Windows server.
"""

__version__ = "2.0.3"
__author__ = "Jason Hu, hyrichard"

from .client import (
    XtQuantRemote,
    connect,
    disconnect,
    get_client,
    xtdata,
    xttrader,
    xttype,
    xtview,
    ConnectionError,
    AuthenticationError,
    CallbackError,
)

__all__ = [
    "XtQuantRemote",
    "connect",
    "disconnect",
    "get_client",
    "xtdata",
    "xttrader",
    "xttype",
    "xtview",
    "ConnectionError",
    "AuthenticationError",
    "CallbackError",
]